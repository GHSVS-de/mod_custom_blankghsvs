<?php
defined('_JEXEC') or die;
/*
From Dispatcher:
$module   Object,
$app,
$input,
$params Registry,
$template,
$modId String,
$moduleclass_sfx String,
$module->title Lang strings translated,
*/
?>
<?php echo $module->content; ?>
